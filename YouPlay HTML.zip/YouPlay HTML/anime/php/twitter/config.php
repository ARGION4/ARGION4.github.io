<?php
/**
 * Your Twitter App Info
 * How to create Twitter API key you can read here (or use google):  - http://www.gabfirethemes.com/create-twitter-api-key/
 */

// Consumer Key
define('CONSUMER_KEY', 'nTonrwrwq5eYGolV4OphwnneX');
define('CONSUMER_SECRET', 'LGWplFGsXEWd09noQzDLDAmg8mJL563fUr3J9EnKLaJeREX4R7');

// User Access Token
define('ACCESS_TOKEN', '2848523763-dNhSczJJcQ2rXjOIItT7Pue4RidjtRu3xB1NVcg');
define('ACCESS_SECRET', 'U0mKRISDYmWcU51I87grlOF7sLO3mgvE84Sr1Ncn5VnSm');

// Cache Settings
define('CACHE_ENABLED', true);
define('CACHE_LIFETIME', 600); // in seconds
define('HASH_SALT', md5(dirname(__FILE__)));
